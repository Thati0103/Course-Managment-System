package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cms.Admin;


public class AdminLoginDao {
	String sqlString = "select * from administrator where username = ? and passwd = ?";
	String urlString = "jdbc:mysql://localhost:3306/cms";
	String usernameString = "root";
	String passwordString = "microsoft2000";
	
	public Admin check(Admin adm) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(sqlString);
		statement.setString(1, adm.getUsername());
		statement.setString(2, adm.getPassword());
		ResultSet rs = statement.executeQuery();
		if(rs.next()) {
			adm.setId(rs.getInt("administrator_id"));  
			adm.setFirstName(rs.getString("firstname"));
			adm.setLastName(rs.getString("lastname"));
			adm.setEmailId(rs.getString("emailid"));
			adm.setValid(true);
			return adm;
		}
		
		return adm;
		
	}
}
