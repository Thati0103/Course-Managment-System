package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AdminDao {
	String instructorString = "select username from instructor where instructor_id != ?";
	String studentString = "select username from student";
	String urlString = "jdbc:mysql://localhost:3306/cms";
	String usernameString = "root";
	String passwordString = "microsoft2000";
	
	public ArrayList<String> getInstructors(ArrayList<String> arr) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(instructorString);
		statement.setInt(1, 1);
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("username")); 
		}
		
		
		return arr;
	}
	
	public ArrayList<String> getStudents(ArrayList<String> arr) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(studentString);
		
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("username")); 
		}
		
		
		return arr;
	}

	
}
