package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;

import com.cms.Instructor;

public class InstructorDao {
	String cnameString = "select * from course where coursename = ?";
	String cnameRemoveString = "select * from course where instructor_id = ? and coursename = ?";
	String insertString = "insert into course(instructor_id,coursename) values(?,?)";
	String embedString = "insert into embed values(?,?,?)";
	String embedCodeString = "select embedcode from embed where instructor_id =? and coursename = ?";
	String coursesString = "select coursename from course where instructor_id = ?";
	String removeString = "delete from course where instructor_id = ? and coursename = ?";
	String urlString = "jdbc:mysql://localhost:3306/cms";
	String usernameString = "root";
	String passwordString = "microsoft2000";
	
	public boolean checkCourseName(Instructor inst) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(cnameString);
		
		statement.setString(1, inst.getCourseName());
		
		ResultSet rs = statement.executeQuery();
		if(!rs.next()) {
			return true;
		}
		
		return false;
	}
	
	public boolean checkRemoveCourseName(Instructor inst) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(cnameRemoveString);
		statement.setInt(1, inst.getId());
		statement.setString(2, inst.getCourseName());
		
		ResultSet rs = statement.executeQuery();
		if(!rs.next()) {
			return true;
		}
		
		return false;
	}
	
	public void addCourse(Instructor inst) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(insertString);
		statement.setInt(1, inst.getId()); 
		statement.setString(2, inst.getCourseName());
		
		statement.executeUpdate();
			
	}
	
	public ArrayList<String> getCourses(Instructor inst,ArrayList<String> arr) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);		
		PreparedStatement statement = conn.prepareStatement(coursesString);
		statement.setInt(1, inst.getId());
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("coursename")); 
		}
		
		
		return arr;
	}
	
	public void addEmbedCode(Instructor inst,String embed) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);		
		PreparedStatement statement = conn.prepareStatement(embedString);
		statement.setInt(1, inst.getId());
		statement.setString(2, inst.getCourseName());
		statement.setString(3, embed);
		
		statement.executeUpdate();
	}
	
	public ArrayList<String> getEmbedCodes(Instructor inst,ArrayList<String> arr) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);		
		PreparedStatement statement = conn.prepareStatement(embedCodeString);
		statement.setInt(1, inst.getId());
		statement.setString(2, inst.getCourseName());
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("embedcode")); 
		}
		
		
		return arr;
	}
	
	public void removeCourse(Instructor inst) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);		
		PreparedStatement statement = conn.prepareStatement(removeString);
		statement.setInt(1, inst.getId());
		statement.setString(2, inst.getCourseName());
		
		statement.executeUpdate();
	}
	
}
