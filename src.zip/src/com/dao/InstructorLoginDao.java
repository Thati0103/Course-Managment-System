package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cms.Instructor;


public class InstructorLoginDao {
	String sqlString = "select * from instructor where username = ? and passwd = ?";
	String unameString = "select * from instructor where username = ?";
	String insertString = "insert into instructor(username,passwd,firstname,lastname,emailid) values(?,?,?,?,?)";
	String urlString = "jdbc:mysql://localhost:3306/cms";
	String usernameString = "root";
	String passwordString = "microsoft2000";

	public Instructor check(Instructor inst)  throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(sqlString);
		statement.setString(1, inst.getUsername());
		statement.setString(2, inst.getPassword());
		ResultSet rs = statement.executeQuery(); 
		if(rs.next()) {
			inst.setId(rs.getInt("instructor_id")); 
			inst.setFirstName(rs.getString("firstname"));
			inst.setLastName(rs.getString("lastname"));
			inst.setEmailId(rs.getString("emailid"));
			inst.setValid(true);
			return inst;
		}
	
		return inst;
	}
	
	
	
	public boolean checkUsername(String uname) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(unameString);
		statement.setString(1, uname);
		ResultSet rs = statement.executeQuery();
		if(!rs.next()) {
			return true;
		}
		return false;
	}
	
	public void addEntry(Instructor inst) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(insertString);
		statement.setString(1, inst.getUsername());
		statement.setString(2, inst.getPassword());
		statement.setString(3, inst.getFirstName());
		statement.setString(4, inst.getLastName());
		statement.setString(5, inst.getEmailId());
		
		statement.executeUpdate();
		
		
	}
	
}
