package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cms.Student;

public class StudentDao {
	String courseString = "select coursename from course where instructor_id != ?";
	String cnameString = "select * from course where student_id = ? and coursename = ?";
	String insertString = "insert into course(student_id,coursename) values(?,?)";
	String myCourseString = "select coursename from course where student_id = ?";
	String embedString = "select embedcode from embed where coursename = ?";
	String removeString = "delete from course where student_id = ? and coursename = ?";
	String urlString = "jdbc:mysql://localhost:3306/cms";
	String usernameString = "root";
	String passwordString = "microsoft2000"; 
	
	public boolean checkCourse(Student stu) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(cnameString);
		statement.setInt(1, stu.getId());
		statement.setString(2, stu.getCourseName());
		
		ResultSet rs = statement.executeQuery();
		if(!rs.next()) {
			return true;
		}
		
		return false;
	}
	
	public ArrayList<String> getAllCourses(ArrayList<String> arr) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(courseString);
		statement.setInt(1, 1);
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("coursename")); 
		}
		
		return arr;
	}
	
	public void registerForCourse(Student stu) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);		
		PreparedStatement statement = conn.prepareStatement(insertString);
		statement.setInt(1, stu.getId());
		statement.setString(2, stu.getCourseName());
		
		statement.executeUpdate();		
		
	}
	
	public ArrayList<String> getCourses(Student stu,ArrayList<String> arr) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);		
		PreparedStatement statement = conn.prepareStatement(myCourseString);
		statement.setInt(1, stu.getId());
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("coursename"));
		}
		
		return arr;
	}
	
	public ArrayList<String> getEmbedCodes(Student stu,ArrayList<String> arr) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);			
		PreparedStatement statement = conn.prepareStatement(embedString);
		statement.setString(1, stu.getCourseName());
		ResultSet rs = statement.executeQuery();
		while(rs.next()) {
			arr.add(rs.getString("embedcode")); 
		}
		
		
		return arr;
	}
	
	public void removeCourse(Student stu) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);			
		PreparedStatement statement = conn.prepareStatement(removeString);
		statement.setInt(1,stu.getId());
		statement.setString(2, stu.getCourseName());
		
		statement.executeUpdate();
		
		

	}
	
}
