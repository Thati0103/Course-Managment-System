package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cms.Student;


public class StudentLoginDao {
	String sqlString = "select * from student where username = ? and passwd = ?";
	String unameString = "select * from student where username = ?";
	String insertString = "insert into student(username,passwd,firstname,lastname,emailid) values(?,?,?,?,?)";
	String urlString = "jdbc:mysql://localhost:3306/cms";
	String usernameString = "root";
	String passwordString = "microsoft2000";
	
	public Student check(Student stu) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(sqlString);
		statement.setString(1, stu.getUsername());
		statement.setString(2, stu.getPassword());
		ResultSet rs = statement.executeQuery();
		if(rs.next()) {
			stu.setId(rs.getInt("student_id"));  
			stu.setFirstName(rs.getString("firstname"));
			stu.setLastName(rs.getString("lastname"));
			stu.setEmailId(rs.getString("emailid"));
			stu.setValid(true);
			return stu;
		}
		
		return stu;
		
	}
	
	public boolean checkUsername(String uname) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement  = conn.prepareStatement(unameString);
		statement.setString(1, uname);
		ResultSet rs = statement.executeQuery();
		if(!rs.next()) {
			return true;
		}
		return false;
	}
	
	public void addEntry(Student stu) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection(urlString,usernameString,passwordString);
		PreparedStatement statement = conn.prepareStatement(insertString);
		statement.setString(1, stu.getUsername());
		statement.setString(2, stu.getPassword());
		statement.setString(3, stu.getFirstName());
		statement.setString(4, stu.getLastName());
		statement.setString(5, stu.getEmailId());
		
		statement.executeUpdate();
		
		
	}
	
	
}
