package com.cms;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.InstructorLoginDao;


/**
 * Servlet implementation class InstructorSignup
 */
@WebServlet("/InstructorSignup")
public class InstructorSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("instructorSignup.jsp");
	}
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		Instructor newInstructor = new Instructor();
		String pass = request.getParameter("pass1");
		if(pass.equals(request.getParameter("pass2"))){
			newInstructor.setUsername(request.getParameter("uname"));
			newInstructor.setPassword(pass);
			newInstructor.setFirstName(request.getParameter("fname"));
			newInstructor.setLastName(request.getParameter("lname"));
			newInstructor.setEmailId(request.getParameter("emailid"));
			
			
			InstructorLoginDao signupDao = new InstructorLoginDao();
			try {
				boolean flag = signupDao.checkUsername(newInstructor.getUsername());
				if(flag) {
					signupDao.addEntry(newInstructor);
					response.sendRedirect("instructorLogin.jsp");
				}
				else {
					response.sendRedirect("instructorSignup.jsp");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		else {
			response.sendRedirect("instructorSignup.jsp");
		}
	}

}
