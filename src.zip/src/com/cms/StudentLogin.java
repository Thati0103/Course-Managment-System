package com.cms;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.StudentLoginDao;

/**
 * Servlet implementation class StudentLogin
 */
@WebServlet("/StudentLogin")
public class StudentLogin extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("studentLogin.jsp");
	}
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		Student newStudent = new Student();
		newStudent.setUsername(request.getParameter("uname"));
		newStudent.setPassword(request.getParameter("pass"));
		
		
		
		StudentLoginDao loginDao = new StudentLoginDao();
		try {
			newStudent = loginDao.check(newStudent);
			if(newStudent.isValid()) {
				HttpSession session = request.getSession();
				session.setAttribute("student", newStudent);
				response.sendRedirect("studentHeader.jsp");
				
			}
			else {
				response.sendRedirect("studentLogin.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
