package com.cms;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.InstructorLoginDao;


/**
 * Servlet implementation class InstructorLogin
 */
@WebServlet("/InstructorLogin")
public class InstructorLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("instructorLogin.jsp");
	}
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		Instructor newInstructor = new Instructor();
		newInstructor.setUsername(request.getParameter("uname"));
		newInstructor.setPassword(request.getParameter("pass"));
		
		
		
		InstructorLoginDao loginDao = new InstructorLoginDao();
		try {
			newInstructor = loginDao.check(newInstructor);
			if(newInstructor.isValid()) {
				HttpSession session = request.getSession();
				session.setAttribute("instructor", newInstructor);
				response.sendRedirect("instructorHeader.jsp");
				
			}
			else {
				response.sendRedirect("instructorLogin.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
