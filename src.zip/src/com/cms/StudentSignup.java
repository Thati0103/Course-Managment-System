package com.cms;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentLoginDao;

/**
 * Servlet implementation class StudentSignup
 */
@WebServlet("/StudentSignup")
public class StudentSignup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("studentSignup.jsp");
	}
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		Student newStudent = new Student();
		String pass = request.getParameter("pass1");
		if(pass.equals(request.getParameter("pass2"))){
			newStudent.setUsername(request.getParameter("uname"));
			newStudent.setPassword(pass);
			newStudent.setFirstName(request.getParameter("fname"));
			newStudent.setLastName(request.getParameter("lname"));
			newStudent.setEmailId(request.getParameter("emailid"));
			
			
			StudentLoginDao signupDao = new StudentLoginDao();
			try {
				boolean flag = signupDao.checkUsername(newStudent.getUsername());
				if(flag) {
					signupDao.addEntry(newStudent);
					response.sendRedirect("studentLogin.jsp");
				}
				else {
					response.sendRedirect("studentSignup.jsp");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		else {
			response.sendRedirect("studentSignup.jsp");
		}
	}


}
