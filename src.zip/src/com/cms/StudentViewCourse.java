package com.cms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.StudentDao;

/**
 * Servlet implementation class StudentViewCourse
 */
@WebServlet("/StudentViewCourse")
public class StudentViewCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		if(session.getAttribute("student") == null){
			response.sendRedirect("studentLogin.jsp");
		}
		
		
		String coursename = request.getParameter("coursename");
		Student newStudent = (Student) session.getAttribute("student");
		newStudent.setCourseName(coursename);
		StudentDao videosDao = new StudentDao();
		ArrayList<String> embeds = new ArrayList<String>();
		
		try {
			embeds = videosDao.getEmbedCodes(newStudent, embeds);
			for(String embedCode : embeds) {
				out.println(embedCode);
				out.println("<br>");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

/*	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}*/

}
