package com.cms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.InstructorDao;

/**
 * Servlet implementation class InstructorContent
 */
@WebServlet("/InstructorContent")
public class InstructorContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		HttpSession session = request.getSession();
		
		
		if(session.getAttribute("instructor") == null){
			response.sendRedirect("instructorLogin.jsp");
		}
		
		
		Instructor newInstructor = (Instructor) session.getAttribute("instructor");
		newInstructor.setCourseName(request.getParameter("coursename"));
		
		InstructorDao courseDao = new InstructorDao();
		try {
			boolean flag = courseDao.checkCourseName(newInstructor);
			if(flag) {
				response.sendRedirect("instructorContent.jsp"); 
			}
			else {
				response.sendRedirect("instructorEmbed.jsp"); 
			}
		} catch (Exception e) {
		
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		
		if(session.getAttribute("instructor") == null){
			response.sendRedirect("instructorLogin.jsp");
		}
		
		Instructor newInstructor = (Instructor) session.getAttribute("instructor");
		InstructorDao embedDao = new InstructorDao();
		
		try {
			embedDao.addEmbedCode(newInstructor, request.getParameter("link"));
			out.println("Video added successfully");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}
