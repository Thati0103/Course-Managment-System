package com.cms;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AdminLoginDao;


/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("adminLogin.jsp");
	}

	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		Admin newAdmin = new Admin();
		newAdmin.setUsername(request.getParameter("uname"));
		newAdmin.setPassword(request.getParameter("pass"));
		
		
		
		AdminLoginDao loginDao = new AdminLoginDao();
		try {
			newAdmin = loginDao.check(newAdmin);
			if(newAdmin.isValid()) {
				HttpSession session = request.getSession();
				session.setAttribute("admin", newAdmin);
				response.sendRedirect("adminHeader.jsp");
				
			}
			else {
				response.sendRedirect("adminLogin.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
