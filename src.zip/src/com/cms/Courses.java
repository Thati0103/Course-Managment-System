package com.cms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.StudentDao;

/**
 * Servlet implementation class Courses
 */
@WebServlet("/Courses")
public class Courses extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		if(session.getAttribute("student") == null){
			response.sendRedirect("studentLogin.jsp");
		}
		
		
		StudentDao coursesDao = new StudentDao();
		ArrayList<String> allCourses = new ArrayList<String>();
		
		try {
			allCourses = coursesDao.getAllCourses(allCourses);
			for(String course : allCourses) {
				String[] coursePieces = course.split("\\s+");
				String courseURL = "";
				for(String piece : coursePieces) {
					courseURL += piece + "+";
				}
				courseURL = courseURL.substring(0, courseURL.length()-1);
				
				out.println("<a href = "+"studentCourseRegister.jsp?coursename="+courseURL+">"+course+"</a>");
				out.println("<br>");
			}
			
			
		} catch (Exception e) {

			e.printStackTrace();
		}
		
	}

/*	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}*/

}
