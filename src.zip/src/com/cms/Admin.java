package com.cms;



public class Admin {
	private int id;
	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String emailId;
	private boolean valid = false;
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setUsername(String uname) {
		username = uname;
	}
	
	public void setPassword(String pass) {
		password = pass;
	}
	
	public void setFirstName(String fName) {
		firstName = fName;
	}
	
	public void setLastName(String lName) {
		lastName = lName;
	}
	
	public void setEmailId(String id) {
		emailId = id;
	}
	
	public void setValid(boolean bool) {
		valid = bool;
	}
	
	public int getId() {
		return id;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getEmailId() {
		return emailId;
	}
	
	public boolean isValid() {
		return valid;
	}
}
